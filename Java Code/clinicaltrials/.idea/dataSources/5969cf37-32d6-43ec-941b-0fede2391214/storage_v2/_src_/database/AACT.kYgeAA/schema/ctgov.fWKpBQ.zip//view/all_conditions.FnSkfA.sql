create view all_conditions(nct_id, names) as
SELECT conditions.nct_id,
       array_to_string(array_agg(DISTINCT conditions.name), '|'::text) AS names
FROM ctgov.conditions
GROUP BY conditions.nct_id;

alter table all_conditions
    owner to ctti;

