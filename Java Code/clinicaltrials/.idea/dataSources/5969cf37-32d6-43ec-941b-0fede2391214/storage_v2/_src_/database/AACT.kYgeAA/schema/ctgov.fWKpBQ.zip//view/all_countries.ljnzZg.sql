create view all_countries(nct_id, names) as
SELECT countries.nct_id,
       array_to_string(array_agg(DISTINCT countries.name), '|'::text) AS names
FROM ctgov.countries
WHERE countries.removed IS NOT TRUE
GROUP BY countries.nct_id;

alter table all_countries
    owner to ctti;

