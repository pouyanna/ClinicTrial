create view all_design_outcomes(nct_id, names) as
SELECT design_outcomes.nct_id,
       array_to_string(array_agg(DISTINCT design_outcomes.measure), '|'::text) AS names
FROM ctgov.design_outcomes
GROUP BY design_outcomes.nct_id;

alter table all_design_outcomes
    owner to ctti;

