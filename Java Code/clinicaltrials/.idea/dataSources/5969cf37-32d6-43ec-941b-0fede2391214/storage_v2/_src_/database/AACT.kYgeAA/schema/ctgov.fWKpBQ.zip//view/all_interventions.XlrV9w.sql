create view all_interventions(nct_id, names) as
SELECT interventions.nct_id,
       array_to_string(array_agg(interventions.name), '|'::text) AS names
FROM ctgov.interventions
GROUP BY interventions.nct_id;

alter table all_interventions
    owner to ctti;

