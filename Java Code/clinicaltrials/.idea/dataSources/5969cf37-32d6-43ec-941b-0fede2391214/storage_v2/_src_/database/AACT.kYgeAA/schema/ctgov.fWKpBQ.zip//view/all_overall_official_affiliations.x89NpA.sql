create view all_overall_official_affiliations(nct_id, names) as
SELECT overall_officials.nct_id,
       array_to_string(array_agg(overall_officials.affiliation), '|'::text) AS names
FROM ctgov.overall_officials
GROUP BY overall_officials.nct_id;

alter table all_overall_official_affiliations
    owner to ctti;

