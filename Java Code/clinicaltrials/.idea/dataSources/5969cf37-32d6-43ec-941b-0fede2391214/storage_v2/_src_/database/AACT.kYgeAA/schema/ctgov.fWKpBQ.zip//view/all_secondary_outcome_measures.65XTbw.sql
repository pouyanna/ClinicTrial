create view all_secondary_outcome_measures(nct_id, names) as
SELECT design_outcomes.nct_id,
       array_to_string(array_agg(DISTINCT design_outcomes.measure), '|'::text) AS names
FROM ctgov.design_outcomes
WHERE design_outcomes.outcome_type::text = 'secondary'::text
GROUP BY design_outcomes.nct_id;

alter table all_secondary_outcome_measures
    owner to ctti;

