create view all_states(nct_id, names) as
SELECT facilities.nct_id,
       array_to_string(array_agg(DISTINCT facilities.state), '|'::text) AS names
FROM ctgov.facilities
GROUP BY facilities.nct_id;

alter table all_states
    owner to ctti;

